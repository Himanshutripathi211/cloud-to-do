function saveNote() {
  const noteInput = document.getElementById("noteInput");
  const note = noteInput.value.trim();
  if (note) {
    db.collection("notes").add({ text: note }).then(() => {
      noteInput.value = "";
      loadNotes();
    });
  }
}

function loadNotes() {
  const notesList = document.getElementById("notesList");
  notesList.innerHTML = "";
  db.collection("notes").get().then(snapshot => {
    snapshot.forEach(doc => {
      const li = document.createElement("li");
      li.textContent = doc.data().text;
      notesList.appendChild(li);
    });
  });
}

document.addEventListener("DOMContentLoaded", loadNotes);