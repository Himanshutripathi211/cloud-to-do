# 🌐 Website Uptime Monitoring App

This app monitors a website's uptime and sends an email alert if it's down.

## Features
- Enter website URL.
- Periodically check if the website is online.
- Sends an email alert if the website is down.

## How to Use
1. Clone the repo.
2. Replace email credentials with your own.
3. Run the app.

## Deploy
- Use a service like Heroku or Railway for backend deployment.