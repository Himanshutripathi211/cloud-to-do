function checkUptime() {
  const urlInput = document.getElementById("urlInput").value;
  const statusElement = document.getElementById("status");
  if (urlInput) {
    fetch(\`uptime-checker.js?url=\${encodeURIComponent(urlInput)}\`)
      .then(response => response.json())
      .then(data => {
        statusElement.textContent = data.message;
        if (!data.isUp) {
          sendAlert(urlInput);
        }
      });
  } else {
    statusElement.textContent = "Please enter a URL.";
  }
}

function sendAlert(url) {
  fetch(\`send-email.js?url=\${encodeURIComponent(url)}\`)
    .then(response => response.json())
    .then(data => {
      console.log(data.message);
    });
}